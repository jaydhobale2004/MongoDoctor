import test from 'node:test';
import assert from 'node:assert/strict';
import {
  parseFilter, recommendIndex, isCovered, groupProfile, findQueryIssues, findIndexIssues,
  inferSchema, findSchemaIssues, healthScore, normalizeFilter,
} from '../src/analyzer.js';

test('parseFilter separates equality, range and complex fields', () => {
  const p = parseFilter({ userId: 'u1', status: { $in: ['a', 'b'] }, createdAt: { $gte: 1 }, name: { $regex: 'x' }, $or: [{ a: 1 }] });
  assert.deepEqual(p.equality, ['userId', 'status']);
  assert.deepEqual(p.range, ['createdAt']);
  assert.deepEqual(p.complex.sort(), ['$or', 'name']);
});

test('parseFilter flattens $and', () => {
  assert.deepEqual(parseFilter({ $and: [{ a: 1 }, { b: { $gt: 2 } }] }).equality, ['a']);
});

test('recommendIndex follows Equality, Sort, Range', () => {
  const rec = recommendIndex({ filter: { userId: 1, createdAt: { $gte: 5 }, status: 'x' }, sort: { score: -1 } });
  assert.deepEqual(rec.keys, [['userId', 1], ['status', 1], ['score', -1], ['createdAt', 1]]);
});

test('recommendIndex does not duplicate a field used in filter and sort', () => {
  const rec = recommendIndex({ filter: { status: 'x' }, sort: { status: 1, createdAt: -1 } });
  assert.deepEqual(rec.keys, [['status', 1], ['createdAt', -1]]);
});

test('recommendIndex returns null when nothing is indexable', () => {
  assert.equal(recommendIndex({ filter: { $or: [{ a: 1 }] } }), null);
});

test('isCovered matches on field-order prefix', () => {
  const idx = [{ key: { userId: 1, status: 1, createdAt: -1 } }];
  assert.equal(isCovered(idx, [['userId', 1], ['status', 1]]), true);
  assert.equal(isCovered(idx, [['status', 1]]), false);
  assert.equal(isCovered([{ key: { userId: 1 } }], [['userId', 1], ['status', 1]]), false);
});

test('normalizeFilter makes queries differing only by value share a shape', () => {
  assert.deepEqual(normalizeFilter({ a: 1, b: { $gt: 3 } }), normalizeFilter({ b: { $gt: 99 }, a: 2 }));
});

const entry = (filter, docs, ret, ms, plan = 'COLLSCAN') => ({
  op: 'query', ns: 'shop.orders', millis: ms, docsExamined: docs, nreturned: ret, planSummary: plan,
  command: { find: 'orders', filter, sort: { createdAt: -1 }, limit: 20 },
});

test('groupProfile merges equal shapes and ignores system namespaces', () => {
  const shapes = groupProfile([
    entry({ userId: 'a', status: 's' }, 1000, 10, 100),
    entry({ userId: 'b', status: 't' }, 3000, 30, 300),
    { op: 'query', ns: 'shop.system.profile', command: { find: 'system.profile', filter: {} } },
    { op: 'command', ns: 'shop.orders', command: { aggregate: 'orders' } },
  ]);
  assert.equal(shapes.length, 1);
  assert.equal(shapes[0].count, 2);
  assert.equal(shapes[0].avgExamined, 2000);
  assert.equal(shapes[0].scanRatio, 100);
});

test('findQueryIssues flags a collection scan and proposes the ESR index', () => {
  const shapes = groupProfile([entry({ userId: 'a', status: 's' }, 200000, 12, 180)]);
  const issues = findQueryIssues(shapes, { 'shop.orders': [{ key: { _id: 1 } }] });
  assert.equal(issues.length, 1);
  assert.equal(issues[0].severity, 'critical');
  assert.equal(issues[0].command, 'db.orders.createIndex({ userId: 1, status: 1, createdAt: -1 })');
});

test('findQueryIssues skips queries that are already indexed or tiny', () => {
  const ok = groupProfile([entry({ userId: 'a' }, 20, 20, 1, 'IXSCAN')]);
  assert.equal(findQueryIssues(ok, {}).length, 0);
  const covered = groupProfile([entry({ userId: 'a' }, 5000, 5, 20)]);
  assert.equal(findQueryIssues(covered, { 'shop.orders': [{ key: { userId: 1, createdAt: -1 } }] }).length, 0);
});

test('findIndexIssues reports redundant and unused indexes, not _id', () => {
  const indexes = [
    { name: '_id_', key: { _id: 1 } },
    { name: 'status_1', key: { status: 1 } },
    { name: 'status_1_createdAt_-1', key: { status: 1, createdAt: -1 } },
    { name: 'note_1', key: { note: 1 } },
  ];
  const stats = [
    { name: 'status_1', accesses: { ops: 0 } },
    { name: 'status_1_createdAt_-1', accesses: { ops: 12 } },
    { name: 'note_1', accesses: { ops: 0, since: '2026-01-01T00:00:00Z' } },
    { name: '_id_', accesses: { ops: 0 } },
  ];
  const types = findIndexIssues('shop.orders', indexes, stats).map((i) => `${i.type}:${i.id.split(':').pop()}`);
  assert.deepEqual(types.sort(), ['redundant_index:status_1', 'unused_index:note_1']);
});

test('findIndexIssues never calls a unique index redundant', () => {
  const indexes = [
    { name: 'email_1', key: { email: 1 }, unique: true },
    { name: 'email_1_x_1', key: { email: 1, x: 1 } },
  ];
  assert.equal(findIndexIssues('a.b', indexes, []).filter((i) => i.type === 'redundant_index').length, 0);
});

test('schema checks: mixed types, big arrays, big documents', () => {
  const docs = [
    ...Array.from({ length: 9 }, () => ({ total: 10, events: [1, 2] })),
    { total: '12.50', events: new Array(25000).fill(0) },
  ];
  const schema = inferSchema(docs, (d) => (d.events.length > 1000 ? 2 * 1024 * 1024 : 100));
  const issues = findSchemaIssues('shop.orders', schema);
  const by = Object.fromEntries(issues.map((i) => [i.type, i]));
  assert.equal(by.type_conflict.severity, 'warning'); // 10% minority
  assert.match(by.type_conflict.detail, /number 90\.0%, string 10\.0%/);
  assert.equal(by.unbounded_array.severity, 'critical');
  assert.equal(by.large_documents.severity, 'critical');
});

test('null alongside a real type is not drift', () => {
  const schema = inferSchema([{ a: null }, { a: 1 }, { a: 2 }]);
  assert.equal(findSchemaIssues('x.y', schema).length, 0);
});

test('healthScore subtracts per severity and floors at 0', () => {
  assert.equal(healthScore([{ severity: 'critical' }, { severity: 'warning' }, { severity: 'info' }]), 77);
  assert.equal(healthScore(Array(10).fill({ severity: 'critical' })), 0);
});

// ---------------------------------------------------------------- v2: aggregations, joins, coercion

import { toQueryLike, collectLookups, findLookupIssues, dedupeLookupIssues, coercionCommand } from '../src/analyzer.js';
import { toMarkdown, toText } from '../src/report.js';

const agg = (pipeline, extra = {}) => ({
  op: 'command', ns: 'shop.users', millis: 100, docsExamined: 20000, nreturned: 20, planSummary: 'COLLSCAN',
  command: { aggregate: 'users', pipeline }, ...extra,
});

test('toQueryLike reads a leading $match (and following $sort) from an aggregation', () => {
  const q = toQueryLike(agg([{ $match: { plan: 'pro' } }, { $sort: { createdAt: -1 } }, { $limit: 5 }]));
  assert.deepEqual(q.filter, { plan: 'pro' });
  assert.deepEqual(q.sort, { createdAt: -1 });
  assert.equal(q.from, 'aggregate');
});

test('toQueryLike ignores pipelines that do not start with $match, and doctor-style stats pipelines', () => {
  assert.equal(toQueryLike(agg([{ $sort: { a: 1 } }, { $match: { b: 1 } }])), null);
  assert.equal(toQueryLike(agg([{ $indexStats: {} }])), null);
  assert.equal(toQueryLike(agg([{ $sample: { size: 5 } }])), null);
});

test('a COLLSCAN that returns a large share of the collection is not flagged', () => {
  const broad = groupProfile([entry({ plan: 'pro' }, 20000, 6600, 40)]); // ratio ~3
  assert.equal(findQueryIssues(broad, {}).length, 0);
  const narrow = groupProfile([entry({ plan: 'pro' }, 20000, 600, 40)]); // ratio ~33
  assert.equal(findQueryIssues(narrow, {}).length, 1);
});

test('collectLookups finds localField/foreignField joins and skips writing pipelines', () => {
  const lk = { $lookup: { from: 'profiles', localField: '_id', foreignField: 'userId', as: 'p' } };
  const found = collectLookups([agg([{ $match: {} }, lk]), agg([{ $match: {} }, lk]), agg([lk, { $out: 'x' }])]);
  assert.equal(found.length, 1);
  assert.equal(found[0].count, 2);
  assert.equal(found[0].foreignNs, 'shop.profiles');
  assert.equal(found[0].foreignField, 'userId');
});

test('findLookupIssues flags an unindexed foreign field on a big collection only', () => {
  const l = { sourceNs: 'shop.users', foreignNs: 'shop.profiles', foreignField: 'userId', count: 6, avgMs: 240, totalMs: 1440, pipeline: [] };
  const idx = { 'shop.profiles': [{ key: { _id: 1 } }] };
  const issues = findLookupIssues([l], idx, { 'shop.profiles': 20000 });
  assert.equal(issues.length, 1);
  assert.equal(issues[0].severity, 'critical');
  assert.equal(issues[0].command, 'db.profiles.createIndex({ userId: 1 })');
  assert.equal(findLookupIssues([l], idx, { 'shop.profiles': 200 }).length, 0);                                  // tiny collection
  assert.equal(findLookupIssues([l], { 'shop.profiles': [{ key: { userId: 1 } }] }, { 'shop.profiles': 20000 }).length, 0); // indexed
  assert.equal(findLookupIssues([{ ...l, foreignField: '_id' }], idx, { 'shop.profiles': 20000 }).length, 0);   // _id is always indexed
});

test('dedupeLookupIssues merges a lookup into a matching find-based recommendation', () => {
  const find = { type: 'missing_index', ns: 'shop.orders', detail: 'd', fix: { keys: [['userId', 1], ['status', 1]] } };
  const lookup = { type: 'lookup_unindexed', ns: 'shop.orders', fix: { keys: [['userId', 1]], sourceNs: 'shop.users' }, metrics: { count: 4 } };
  const out = dedupeLookupIssues([find, lookup]);
  assert.equal(out.length, 1);
  assert.match(out[0].detail, /also speeds up the \$lookup from users \(4 runs\)/);
  assert.equal(dedupeLookupIssues([lookup]).length, 1); // nothing to merge into
});

test('coercionCommand converts strays to the dominant type and refuses unsafe cases', () => {
  assert.equal(
    coercionCommand('orders', 'total', 'number', ['string']),
    'db.orders.updateMany({ "total": { $type: "string" } }, [{ $set: { "total": { $convert: { input: "$total", to: "double", onError: "$total" } } } }])',
  );
  assert.equal(coercionCommand('orders', 'x', 'object', ['string']), null);
  assert.equal(coercionCommand('orders', 'x', 'string', ['array']), null);
});

test('type_conflict issues carry the coercion command', () => {
  const schema = inferSchema([...Array.from({ length: 9 }, () => ({ total: 1 })), { total: 'x' }]);
  const issue = findSchemaIssues('shop.orders', schema).find((i) => i.type === 'type_conflict');
  assert.match(issue.command, /\$convert/);
  assert.match(issue.detail, /Try it on a copy first/);
});

test('report renderers include every finding', () => {
  const r = {
    db: 'shop', score: 70, generatedAt: 'now', warnings: ['a note'], collections: [{ name: 'orders', count: 10, indexes: 1 }],
    issues: [{ severity: 'critical', title: 'T1', ns: 'shop.orders', detail: 'D1', command: 'db.orders.createIndex({ a: 1 })', query: 'db.orders.find({})' }],
  };
  const md = toMarkdown(r);
  assert.match(md, /## CRITICAL: T1/);
  assert.match(md, /createIndex/);
  assert.match(md, /a note/);
  assert.match(toText(r), /\[CRITICAL\] T1/);
});
