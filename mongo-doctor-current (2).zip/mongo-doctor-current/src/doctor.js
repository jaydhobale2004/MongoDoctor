import { MongoClient, BSON } from 'mongodb';
import {
  groupProfile, collectLookups, findQueryIssues, findLookupIssues, dedupeLookupIssues,
  findIndexIssues, inferSchema, findSchemaIssues, healthScore, sortIssues,
} from './analyzer.js';

const { EJSON } = BSON;
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
export const INDEX_PREFIX = 'doctor_';

export async function connect(uri) {
  const client = new MongoClient(uri, { serverSelectionTimeoutMS: 3000 });
  await client.connect();
  await client.db('admin').command({ ping: 1 });
  return client;
}

export async function listDatabases(client) {
  const { databases } = await client.db('admin').admin().listDatabases();
  return databases.map((d) => d.name).filter((n) => !['admin', 'local', 'config'].includes(n));
}

/** Human-readable shell version of a find, for display. */
export function describeQuery(coll, { filter, sort, limit, from }) {
  const f = EJSON.stringify(filter || {}, { relaxed: true });
  if (from === 'aggregate') return `db.${coll}.aggregate([{ $match: ${f} }${sort ? `, { $sort: ${JSON.stringify(sort)} }` : ''}, ...])`;
  let s = `db.${coll}.find(${f})`;
  if (sort) s += `.sort(${JSON.stringify(sort)})`;
  if (limit) s += `.limit(${limit})`;
  return s;
}

export async function analyze(client, dbName, { sampleSize = 300 } = {}) {
  const db = client.db(dbName);
  const warnings = [];
  const names = (await db.listCollections({ type: 'collection' }).toArray())
    .map((c) => c.name)
    .filter((n) => !n.startsWith('system.'));

  // Profiler access is not available everywhere (Atlas shared tiers, some compatible servers).
  let level = null;
  try { level = (await db.command({ profile: -1 })).was; }
  catch { warnings.push('Profiler status is unavailable on this server, so query history may be missing.'); }

  let entries = [];
  try {
    entries = await db.collection('system.profile')
      .find({
        ns: { $regex: `^${escapeRegex(dbName)}\\.` },
        $or: [{ op: 'query' }, { op: 'command', 'command.aggregate': { $exists: true } }],
      })
      .sort({ ts: -1 }).limit(5000).toArray();
  } catch { /* profile collection may not exist */ }

  const collections = [];
  const indexesByNs = {};
  const countsByNs = {};
  const issues = [];

  for (const name of names) {
    const ns = `${dbName}.${name}`;
    try {
      const coll = db.collection(name);
      const indexes = await coll.indexes();
      indexesByNs[ns] = indexes;
      let stats = [];
      try { stats = await coll.aggregate([{ $indexStats: {} }]).toArray(); } catch { /* not permitted */ }
      const count = await coll.estimatedDocumentCount();
      countsByNs[ns] = count;
      collections.push({ name, count, indexes: indexes.length });

      issues.push(...findIndexIssues(ns, indexes, stats));
      if (count > 0) {
        const size = Math.min(sampleSize, count);
        let docs;
        try { docs = await coll.aggregate([{ $sample: { size } }]).toArray(); }
        catch { docs = await coll.find({}).limit(size).toArray(); } // servers without $sample: first N documents
        issues.push(...findSchemaIssues(ns, inferSchema(docs, (d) => BSON.calculateObjectSize(d))));
      }
    } catch (err) {
      warnings.push(`Skipped ${name}: ${err.message}`);
    }
  }

  const shapes = groupProfile(entries);
  issues.push(...findQueryIssues(shapes, indexesByNs));
  issues.push(...findLookupIssues(collectLookups(entries), indexesByNs, countsByNs));

  if (level === 0 && entries.length === 0) {
    issues.push({
      id: 'profiler_off', type: 'profiler_off', severity: 'info', ns: dbName,
      title: 'No query history to analyse',
      detail: 'The profiler is off and system.profile is empty, so only index and schema checks ran.',
      command: 'db.setProfilingLevel(1, { slowms: 50 })',
    });
  }

  const final = dedupeLookupIssues(issues);
  for (const i of final) {
    if (i.fix?.example) i.query = describeQuery(i.ns.slice(i.ns.indexOf('.') + 1), i.fix.example);
  }
  const sorted = sortIssues(final);
  return {
    db: dbName,
    generatedAt: new Date().toISOString(),
    profiler: { level, queriesAnalysed: entries.length, shapes: shapes.length },
    collections,
    warnings,
    score: healthScore(sorted),
    issues: sorted,
  };
}

// ---------------------------------------------------------------- explain + fix

function summarisePlan(out) {
  const es = out.executionStats;
  const plan = JSON.stringify(out.queryPlanner?.winningPlan ?? {});
  return {
    docsExamined: es.totalDocsExamined,
    keysExamined: es.totalKeysExamined,
    returned: es.nReturned,
    ms: es.executionTimeMillis,
    stage: plan.includes('"COLLSCAN"') ? 'COLLSCAN' : plan.includes('"IXSCAN"') ? 'IXSCAN' : 'OTHER',
    inMemorySort: plan.includes('"stage":"SORT"'),
  };
}

const median = (a) => [...a].sort((x, y) => x - y)[Math.floor(a.length / 2)];

export async function explainFind(db, collName, { filter, sort, limit }) {
  const find = { find: collName, filter: filter || {} };
  if (sort) find.sort = sort;
  if (limit) find.limit = limit;
  const out = await db.command({ explain: find, verbosity: 'executionStats' });
  return summarisePlan(out);
}

/** Explain 3 times: docs examined is deterministic, time is the median to damp cache noise. */
export async function measureFind(db, collName, example, runs = 3) {
  const results = [];
  for (let i = 0; i < runs; i++) results.push(await explainFind(db, collName, example));
  return { ...results[results.length - 1], ms: median(results.map((r) => r.ms)) };
}

const WRITES = ['$out', '$merge'];
const LOOKUP_SAMPLE = 20;

/** Wall-clock time of an aggregation, capped to the first N output documents. Median of 3. */
export async function measureLookup(db, sourceColl, pipeline, runs = 3) {
  if (pipeline.some((st) => WRITES.some((w) => st && w in st))) throw new Error('Refusing to run a pipeline that writes.');
  const capped = [...pipeline, { $limit: LOOKUP_SAMPLE }];
  const times = [];
  for (let i = 0; i < runs; i++) {
    const t0 = performance.now();
    await db.collection(sourceColl).aggregate(capped, { maxTimeMS: 30000 }).toArray();
    times.push(Math.round(performance.now() - t0));
  }
  return { ms: median(times), docsExamined: null, returned: null, stage: null };
}

export const indexName = (keys) => INDEX_PREFIX + keys.map(([f, d]) => `${f}_${d}`).join('_');
const collOf = (ns) => ns.slice(ns.indexOf('.') + 1);

/** Measure, build the index, measure again. */
export async function applyFix(client, entry) {
  const db = client.db(entry.db);
  const keys = entry.keys;
  const name = indexName(keys);

  if (entry.kind === 'lookup') {
    const source = collOf(entry.sourceNs);
    const before = await measureLookup(db, source, entry.pipeline);
    await db.collection(collOf(entry.foreignNs)).createIndex(Object.fromEntries(keys), { name });
    const after = await measureLookup(db, source, entry.pipeline);
    return { name, ns: entry.foreignNs, before, after,
      note: `Timed the join from ${source} for its first ${LOOKUP_SAMPLE} results (median of 3 runs).` };
  }

  const coll = collOf(entry.ns);
  const before = await measureFind(db, coll, entry.example);
  await db.collection(coll).createIndex(Object.fromEntries(keys), { name });
  const after = await measureFind(db, coll, entry.example);
  return { name, ns: entry.ns, before, after };
}

export async function revertFix(client, { db: dbName, ns, name }) {
  if (!name.startsWith(INDEX_PREFIX)) throw new Error('Only indexes created by Mongo Doctor can be removed here.');
  await client.db(dbName).collection(collOf(ns)).dropIndex(name);
  return { dropped: name };
}
