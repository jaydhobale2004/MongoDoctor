// Static report for previewing the dashboard without a database.
// These numbers are illustrative, NOT measured. The UI labels it as sample data and disables fixes.
export const sampleReport = {
  sample: true,
  db: 'shop',
  generatedAt: '2026-01-01T00:00:00.000Z',
  profiler: { level: 2, queriesAnalysed: 60, shapes: 4 },
  warnings: [],
  collections: [
    { name: 'orders', count: 200000, indexes: 4 },
    { name: 'users', count: 20000, indexes: 1 },
    { name: 'sessions', count: 2055, indexes: 1 },
  ],
  score: 33,
  issues: [
    {
      id: 's1', type: 'missing_index', severity: 'critical', ns: 'shop.orders',
      title: 'Queries on orders read 200,000 documents to return 12',
      detail: 'Seen 15x, averaging 180 ms. Plan: COLLSCAN. An index on { userId: 1, status: 1, createdAt: -1 } lets MongoDB jump straight to the matching documents.',
      query: 'db.orders.find({"userId":"…","status":"shipped"}).sort({"createdAt":-1}).limit(20)',
      command: 'db.orders.createIndex({ userId: 1, status: 1, createdAt: -1 })',
      metrics: { count: 15, avgMs: 180, avgExamined: 200000, avgReturned: 12, scanRatio: 16666, plan: 'COLLSCAN' },
      fix: { keys: [['userId', 1], ['status', 1], ['createdAt', -1]] },
    },
    {
      id: 's5', type: 'lookup_unindexed', severity: 'critical', ns: 'shop.profiles',
      title: '$lookup into profiles matches on unindexed userId',
      detail: 'The join from users ran 6x, averaging 240 ms. With no index on profiles.userId, MongoDB scans all 20,000 documents of profiles for every document it joins.',
      command: 'db.profiles.createIndex({ userId: 1 })',
      fix: { kind: 'lookup', keys: [['userId', 1]] },
    },
    {
      id: 's2', type: 'unbounded_array', severity: 'critical', ns: 'shop.sessions',
      title: 'sessions.events grows without a bound',
      detail: 'The longest array in the sample holds 25,000 items. Large arrays inflate documents, slow updates and push toward the 16 MB document limit. Move the items to their own collection.',
      command: null,
    },
    {
      id: 's3', type: 'type_conflict', severity: 'warning', ns: 'shop.orders',
      title: 'orders.total stores mixed types',
      detail: 'In 300 sampled documents: number 92.0%, string 8.0%. Mixed types break sorting, range queries and aggregations, because MongoDB orders values by type first.',
      command: null,
    },
    {
      id: 's4', type: 'redundant_index', severity: 'warning', ns: 'shop.orders',
      title: 'Index status_1 on orders is redundant',
      detail: 'status_1_createdAt_-1 already starts with the same fields, so status_1 only adds write cost and storage.',
      command: 'db.orders.dropIndex("status_1")',
    },
  ],
};
