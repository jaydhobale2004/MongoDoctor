// Minimal .env loader (no dependency). Real environment variables win over the file.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const defaultFile = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '.env');

export function loadEnv(file = defaultFile, env = process.env) {
  if (!fs.existsSync(file)) return;

  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    const value = m[2].replace(/^(['"])(.*)\1$/, '$2');
    if (value && !env[m[1]]?.trim()) env[m[1]] = value;
  }
}

loadEnv();
