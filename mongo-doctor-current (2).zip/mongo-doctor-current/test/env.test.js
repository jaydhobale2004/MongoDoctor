import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { loadEnv } from '../src/env.js';

test('loadEnv fills empty environment variables without overriding configured values', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mongo-doctor-env-'));
  const file = path.join(dir, '.env');

  try {
    fs.writeFileSync(file, 'NVIDIA_API_KEY=file-key\nANTHROPIC_API_KEY=file-anthropic-key\n');
    const env = { NVIDIA_API_KEY: '', ANTHROPIC_API_KEY: 'environment-key' };

    loadEnv(file, env);

    assert.equal(env.NVIDIA_API_KEY, 'file-key');
    assert.equal(env.ANTHROPIC_API_KEY, 'environment-key');
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
