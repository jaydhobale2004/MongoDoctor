// End-to-end check against YOUR MongoDB: seeds a small database, runs the real scan,
// applies fixes, and asserts the improvement. Run it first:  npm run selfcheck
import { MongoClient } from 'mongodb';
import { connect, analyze, applyFix, revertFix } from '../src/doctor.js';

const uri = process.env.MONGO_URI || 'mongodb://localhost:27017';
const DB = 'doctor_selfcheck';
const results = [];
let state = {};

async function step(name, fn, { needs } = {}) {
  if (needs && !state[needs]) {
    results.push({ name, status: 'skip', msg: `needs "${needs}"` });
    return false;
  }
  try {
    const msg = await fn();
    results.push({ name, status: 'pass', msg: msg || '' });
    return true;
  } catch (err) {
    results.push({ name, status: 'fail', msg: err.message });
    return false;
  }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg); };
const pick = (a) => a[Math.floor(Math.random() * a.length)];

const client = await connect(uri).catch((e) => { console.error(`Cannot connect to ${uri}: ${e.message}`); process.exit(2); });
const db = client.db(DB);

state.seeded = await step('seed small database', async () => {
  await db.dropDatabase();
  const N = 30000, C = 3000;
  const orders = Array.from({ length: N }, (_, i) => ({
    customerId: i % C, status: pick(['paid', 'shipped', 'pending']),
    total: Math.random() < 0.1 ? '12.50' : Math.round(Math.random() * 10000) / 100,
    createdAt: new Date(Date.now() - Math.random() * 3e10), pad: 'x'.repeat(200),
  }));
  for (let i = 0; i < N; i += 5000) await db.collection('orders').insertMany(orders.slice(i, i + 5000));
  await db.collection('customers').insertMany(Array.from({ length: C }, (_, i) => ({ _id: i, region: pick(['eu', 'us', 'apac', 'latam']) })));
  await db.collection('profiles').insertMany(Array.from({ length: 15000 }, (_, i) => ({ customerId: i % C, bio: 'y'.repeat(100) })));
  return `${N} orders, ${C} customers, 15000 profiles`;
});

state.profiler = await step('enable profiler (level 2)', async () => {
  await db.command({ profile: 2, slowms: 0 });
}, { needs: 'seeded' });

await step('run workload', async () => {
  for (let i = 0; i < 10; i++) await db.collection('orders').find({ customerId: i * 7, status: 'paid' }).sort({ createdAt: -1 }).limit(10).toArray();
  for (let i = 0; i < 5; i++) {
    await db.collection('customers').aggregate([
      { $match: { region: 'eu' } },
      { $lookup: { from: 'profiles', localField: '_id', foreignField: 'customerId', as: 'p' } },
      { $limit: 20 },
    ]).toArray();
  }
  await db.command({ profile: 0 }); // freeze the history
}, { needs: 'profiler' });

let report;
state.scanned = await step('scan finds the problems', async () => {
  report = await analyze(client, DB);
  const types = report.issues.map((i) => `${i.type}`);
  const has = (t, test = () => true) => report.issues.find((i) => i.type === t && test(i));
  assert(has('type_conflict', (i) => i.title.includes('orders.total')), 'no mixed-type finding for orders.total');
  if (state.profiler) {
    assert(has('missing_index', (i) => i.ns === `${DB}.orders` && i.fix.keys.map((k) => k[0]).join() === 'customerId,status,createdAt'),
      `no missing_index for orders (got: ${types.join(', ')})`);
    assert(has('lookup_unindexed', (i) => i.ns === `${DB}.profiles`), `no lookup_unindexed for profiles (got: ${types.join(', ')})`);
  }
  return `${report.issues.length} issues, score ${report.score}`;
}, { needs: 'seeded' });

const entryOf = (i) => ({ db: DB, ns: i.ns, ...i.fix });

state.fixed = await step('fix a missing index: docs examined drops, COLLSCAN becomes IXSCAN', async () => {
  const issue = report.issues.find((i) => i.type === 'missing_index' && i.ns === `${DB}.orders`);
  assert(issue, 'no missing_index issue to fix');
  const r = await applyFix(client, entryOf(issue));
  state.fixName = r.name;
  assert(r.before.stage === 'COLLSCAN', `expected COLLSCAN before, got ${r.before.stage}`);
  assert(r.after.stage === 'IXSCAN', `expected IXSCAN after, got ${r.after.stage}`);
  assert(r.after.docsExamined < r.before.docsExamined, 'docs examined did not drop');
  return `${r.before.docsExamined} -> ${r.after.docsExamined} docs examined, ${r.before.ms} -> ${r.after.ms} ms`;
}, { needs: 'scanned' });

await step('fix a $lookup: join gets faster', async () => {
  const issue = report.issues.find((i) => i.type === 'lookup_unindexed');
  assert(issue, 'no lookup issue to fix');
  const r = await applyFix(client, entryOf(issue));
  state.lookupName = r.name;
  assert(Number.isFinite(r.before.ms) && Number.isFinite(r.after.ms), 'timings missing');
  assert(r.after.ms < r.before.ms, `join not faster (${r.before.ms} -> ${r.after.ms} ms)`);
  return `${r.before.ms} -> ${r.after.ms} ms`;
}, { needs: 'fixed' });

await step('re-scan: the fixed finding is gone', async () => {
  const again = await analyze(client, DB);
  assert(!again.issues.some((i) => i.type === 'missing_index' && i.ns === `${DB}.orders`), 'missing_index still reported');
  return `score ${report.score} -> ${again.score}`;
}, { needs: 'fixed' });

await step('revert removes only doctor_ indexes', async () => {
  await revertFix(client, { db: DB, ns: `${DB}.orders`, name: state.fixName });
  const names = (await db.collection('orders').indexes()).map((i) => i.name);
  assert(!names.includes(state.fixName), 'index still present');
  let refused = false;
  try { await revertFix(client, { db: DB, ns: `${DB}.orders`, name: '_id_' }); } catch { refused = true; }
  assert(refused, 'revert allowed dropping a non-doctor index');
}, { needs: 'fixed' });

await db.dropDatabase().catch(() => {});
await client.close();

const sym = { pass: 'PASS', fail: 'FAIL', skip: 'SKIP' };
console.log(`\nMongo Doctor self-check against ${uri}\n`);
for (const r of results) console.log(`${sym[r.status]}  ${r.name}${r.msg ? `\n      ${r.msg}` : ''}`);
const failed = results.filter((r) => r.status === 'fail').length;
console.log(`\n${results.filter((r) => r.status === 'pass').length} passed, ${failed} failed, ${results.filter((r) => r.status === 'skip').length} skipped`);
process.exit(failed ? 1 : 0);
