// Builds a deliberately unhealthy "shop" database so Mongo Doctor has something to find:
//  - orders.userId, users.email, sessions.userId have no index   -> collection scans
//  - orders has a redundant index and an unused index
//  - orders.total / users.age are sometimes strings               -> type drift
//  - sessions.events arrays are huge for a few documents          -> unbounded arrays, 1 MB+ docs
//  - a $lookup joins users to profiles on an unindexed field       -> slow join
import { MongoClient, ObjectId } from 'mongodb';

const uri = process.env.MONGO_URI || 'mongodb://localhost:27017';
const DB = process.env.SEED_DB || 'shop';
const N_USERS = 20_000;
const N_ORDERS = 200_000;
const N_SESSIONS = 2_000;

const pick = (a) => a[Math.floor(Math.random() * a.length)];
const int = (lo, hi) => lo + Math.floor(Math.random() * (hi - lo + 1));
const COUNTRIES = ['IE', 'GB', 'DE', 'FR', 'ES', 'IN', 'US', 'CA', 'NL', 'SE'];
const STATUSES = ['pending', 'paid', 'shipped', 'delivered', 'cancelled'];
const now = Date.now();
const daysAgo = (d) => new Date(now - d * 86_400_000);

async function insertInBatches(coll, make, total, size = 5000) {
  for (let i = 0; i < total; i += size) {
    const batch = [];
    for (let j = i; j < Math.min(i + size, total); j++) batch.push(make(j));
    await coll.insertMany(batch, { ordered: false });
  }
}

const client = new MongoClient(uri, { serverSelectionTimeoutMS: 4000, ignoreUndefined: true });
await client.connect();
const db = client.db(DB);
await db.dropDatabase();
console.log(`Seeding "${DB}" on ${uri} ...`);

const userIds = Array.from({ length: N_USERS }, () => new ObjectId());
await insertInBatches(db.collection('users'), (i) => ({
  _id: userIds[i],
  email: `user${i}@example.com`,
  name: `User ${i}`,
  country: pick(COUNTRIES),
  plan: pick(['free', 'pro', 'team']),
  age: Math.random() < 0.12 ? String(int(18, 70)) : int(18, 70), // ~12% stored as strings
  createdAt: daysAgo(int(0, 900)),
}), N_USERS);

await insertInBatches(db.collection('orders'), () => ({
  userId: pick(userIds),
  status: pick(STATUSES),
  total: Math.random() < 0.08 ? (int(500, 50000) / 100).toFixed(2) : int(500, 50000) / 100, // ~8% strings
  country: pick(COUNTRIES),
  items: Array.from({ length: int(1, 5) }, () => ({ sku: `SKU-${int(1, 900)}`, qty: int(1, 4), price: int(100, 9000) / 100 })),
  note: Math.random() < 0.02 ? 'gift' : undefined,
  createdAt: daysAgo(int(0, 730)),
}), N_ORDERS, 10_000);

// Three index states: redundant, useful, unused.
const orders = db.collection('orders');
await orders.createIndex({ status: 1 });                 // redundant: prefix of the next one
await orders.createIndex({ status: 1, createdAt: -1 });  // useful for the control query below
await orders.createIndex({ note: 1 });                   // never queried

// Sessions: a few documents with enormous event arrays.
const event = () => ({ t: now - int(0, 1e9), type: pick(['click', 'view', 'scroll']), path: `/p/${int(1, 500)}` });
await insertInBatches(db.collection('sessions'), (i) => {
  const n = i < 15 ? 25_000 : i < 55 ? 8_000 : int(20, 200);
  return { userId: pick(userIds), startedAt: daysAgo(int(0, 30)), events: Array.from({ length: n }, event) };
}, N_SESSIONS, 100);

// Profiles: joined from users with $lookup, no index on userId.
await insertInBatches(db.collection('profiles'), (i) => ({
  userId: userIds[i], bio: `Bio for user ${i}`, avatarUrl: `https://img.example.com/${i}.png`,
}), N_USERS);

// Turn on the profiler for every operation, then run a realistic workload.
await db.command({ profile: 2, slowms: 0 });
const sample = (n) => Array.from({ length: n }, () => pick(userIds));

for (const id of sample(15)) {
  await orders.find({ userId: id, status: 'shipped' }).sort({ createdAt: -1 }).limit(20).toArray(); // COLLSCAN
}
for (let i = 0; i < 15; i++) {
  await db.collection('users').findOne({ email: `user${int(0, N_USERS - 1)}@example.com` });         // COLLSCAN
}
for (const id of sample(10)) {
  await db.collection('sessions').find({ userId: id }, { projection: { userId: 1, startedAt: 1 } }).toArray(); // COLLSCAN
}
for (let i = 0; i < 6; i++) {
  await db.collection('users').aggregate([                                                             // COLLSCAN + slow $lookup
    { $match: { plan: 'pro', country: pick(COUNTRIES) } },
    { $lookup: { from: 'profiles', localField: '_id', foreignField: 'userId', as: 'profile' } },
    { $limit: 20 },
  ]).toArray();
}
for (let i = 0; i < 10; i++) {
  await orders.find({ status: 'pending', createdAt: { $gte: daysAgo(30) } }).limit(50).toArray();    // uses an index: control
}

// Stop recording so later checkups don't push this workload out of the capped system.profile collection.
await db.command({ profile: 0 });
console.log('Done. The workload is saved in system.profile and the profiler is switched off to keep it.');
console.log('Run:  npm start   then open http://localhost:3000');
await client.close();
