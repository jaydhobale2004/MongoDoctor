import './env.js';
import express from 'express';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { connect, listDatabases, analyze, applyFix, revertFix } from './doctor.js';
import { sampleReport } from './sample.js';
import { toMarkdown } from './report.js';

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017';
const PORT = Number(process.env.PORT || 3000);
const here = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(express.json());
app.use(express.static(path.join(here, '..', 'public')));

let clientPromise = null;
function getClient() {
  if (!clientPromise) {
    clientPromise = connect(MONGO_URI).catch((err) => {
      clientPromise = null;
      const e = new Error(`Cannot reach MongoDB at ${MONGO_URI}. Start it with "docker compose up -d" or set MONGO_URI.`);
      e.status = 503;
      e.cause = err;
      throw e;
    });
  }
  return clientPromise;
}

// Fix payloads stay on the server. The browser only gets an opaque token, so it can't
// ask for arbitrary indexes and BSON types (ObjectId, Date) survive the round trip.
const fixes = new Map();
const lastReport = new Map(); // db -> most recent report, for the Markdown export

const wrap = (fn) => async (req, res) => {
  try {
    res.json(await fn(req, res));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
};

app.get('/api/databases', wrap(async () => ({ databases: await listDatabases(await getClient()) })));

app.get('/api/scan', wrap(async (req) => {
  const db = String(req.query.db || '').trim();
  if (!db) throw Object.assign(new Error('Pick a database to check.'), { status: 400 });
  const report = await analyze(await getClient(), db);
  for (const issue of report.issues) {
    if (!issue.fix) continue;
    const token = randomUUID();
    fixes.set(token, { db, ns: issue.ns, ...issue.fix }); // kind, keys, example / pipeline stay server-side
    issue.fix = { token, keys: issue.fix.keys, kind: issue.fix.kind || 'find' };
  }
  lastReport.set(db, report);
  return report;
}));

app.post('/api/fix', wrap(async (req) => {
  const entry = fixes.get(req.body?.token);
  if (!entry) throw Object.assign(new Error('This fix has expired. Run the checkup again.'), { status: 404 });
  return { ns: entry.ns, ...(await applyFix(await getClient(), entry)) };
}));

app.post('/api/revert', wrap(async (req) => {
  const { db, ns, name } = req.body || {};
  if (![db, ns, name].every((v) => typeof v === 'string' && v)) {
    throw Object.assign(new Error('db, ns and name are required.'), { status: 400 });
  }
  return revertFix(await getClient(), { db, ns, name });
}));

app.get('/api/sample', (_req, res) => res.json(sampleReport));

app.get('/api/report.md', (req, res) => {
  const report = lastReport.get(String(req.query.db || ''));
  if (!report) return res.status(404).type('text').send('Run a checkup first.');
  res.type('text/markdown').set('Content-Disposition', `attachment; filename="mongo-doctor-${report.db}.md"`).send(toMarkdown(report));
});

// Optional: plain-English explanation from an LLM.
// Uses NVIDIA (NVIDIA_API_KEY) if set, otherwise Anthropic (ANTHROPIC_API_KEY).
const isKey = (v) => Boolean(v) && !/paste|your-key|changeme/i.test(v);

async function askModel(prompt) {
  if (isKey(process.env.NVIDIA_API_KEY)) {
    const r = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${process.env.NVIDIA_API_KEY}` },
      body: JSON.stringify({
        model: 'nvidia/nemotron-3.5-lightning-30b-a3b',
        messages: [
          { role: 'system', content: 'You are a MongoDB performance engineer. Return only the final explanation in under 120 words. Do not include reasoning, analysis, or a thinking process. No headings or markdown.' },
          { role: 'user', content: prompt },
        ],
        chat_template_kwargs: { enable_thinking: false },
        max_tokens: 200,
        temperature: 1.0,
      }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data?.detail || data?.error?.message || `NVIDIA API error (${r.status})`), { status: 502 });
    return data.choices?.[0]?.message?.content?.trim() || '';
  }
  if (isKey(process.env.ANTHROPIC_API_KEY)) {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
        max_tokens: 400,
        messages: [{ role: 'user', content: prompt }],
      }),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data?.error?.message || `Anthropic API error (${r.status})`), { status: 502 });
    return data.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
  }
  throw Object.assign(new Error('Set NVIDIA_API_KEY (or ANTHROPIC_API_KEY) to enable explanations.'), { status: 501 });
}

app.post('/api/explain', wrap(async (req) => {
  const { title, detail, command, metrics } = req.body || {};
  const prompt =
    'Explain why this finding hurts, what to change, and any risk of the fix:\n\n' +
    JSON.stringify({ title, detail, command, metrics });
  return { text: await askModel(prompt) };
}));

app.listen(PORT, '127.0.0.1', () => {
  console.log(`Mongo Doctor running at http://localhost:${PORT}  (MongoDB: ${MONGO_URI})`);
});
