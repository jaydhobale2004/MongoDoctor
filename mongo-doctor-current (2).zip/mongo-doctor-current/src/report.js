// Plain-text and Markdown renderers, shared by the CLI and the server.
const ICON = { critical: 'CRITICAL', warning: 'WARNING', info: 'INFO' };

export function toMarkdown(r) {
  const counts = { critical: 0, warning: 0, info: 0 };
  r.issues.forEach((i) => counts[i.severity]++);
  const docs = r.collections.reduce((a, c) => a + c.count, 0);
  const out = [
    `# Mongo Doctor report: ${r.db}`,
    '',
    `Health score **${r.score}/100** · ${counts.critical} critical, ${counts.warning} warning, ${counts.info} info`,
    `${r.collections.length} collections, ${docs.toLocaleString('en-US')} documents · generated ${r.generatedAt}`,
    '',
  ];
  if (r.warnings?.length) out.push('> Notes: ' + r.warnings.join(' '), '');
  if (!r.issues.length) out.push('No problems found.');
  for (const i of r.issues) {
    out.push(`## ${ICON[i.severity]}: ${i.title}`, '', `\`${i.ns}\``, '', i.detail, '');
    if (i.query) out.push('Query:', '```js', i.query, '```', '');
    if (i.command) out.push('Suggested command:', '```js', i.command, '```', '');
  }
  return out.join('\n');
}

export function toText(r) {
  const lines = [`Mongo Doctor: ${r.db}   health ${r.score}/100`];
  for (const w of r.warnings || []) lines.push(`  note: ${w}`);
  for (const i of r.issues) {
    lines.push('', `[${ICON[i.severity]}] ${i.title}`, `  ${i.ns}`, `  ${i.detail}`);
    if (i.command) lines.push(`  fix: ${i.command}`);
  }
  if (!r.issues.length) lines.push('', 'No problems found.');
  return lines.join('\n');
}
