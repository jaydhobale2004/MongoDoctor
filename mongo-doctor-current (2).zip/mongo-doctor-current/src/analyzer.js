// Pure analysis logic. No database access in this file, so it is unit-testable.

const RANGE_OPS = new Set(['$gt', '$gte', '$lt', '$lte']);
const EQ_OPS = new Set(['$eq', '$in']);
const uniq = (a) => [...new Set(a)];

export const fmtNum = (n) => Math.round(n).toLocaleString('en-US');
export function fmtBytes(b) {
  if (b >= 1024 * 1024) return `${(b / 1024 / 1024).toFixed(1)} MB`;
  if (b >= 1024) return `${Math.round(b / 1024)} KB`;
  return `${b} B`;
}

export function isPlainObject(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v) && Object.getPrototypeOf(v) === Object.prototype;
}
const isOperatorObject = (v) =>
  isPlainObject(v) && Object.keys(v).length > 0 && Object.keys(v).every((k) => k.startsWith('$'));

// ---------------------------------------------------------------- queries

/** Split a find() filter into equality fields, range fields and things we can't index for. */
export function parseFilter(filter = {}) {
  const equality = [];
  const range = [];
  const complex = [];
  const walk = (f) => {
    for (const [k, v] of Object.entries(f || {})) {
      if (k === '$and' && Array.isArray(v)) {
        v.forEach(walk);
      } else if (k.startsWith('$')) {
        complex.push(k); // $or, $nor, $text, $expr ...
      } else if (isOperatorObject(v)) {
        const ops = Object.keys(v);
        if (ops.some((o) => RANGE_OPS.has(o))) range.push(k);
        else if (ops.every((o) => EQ_OPS.has(o))) equality.push(k);
        else complex.push(k); // $ne, $regex, $exists, $nin ...
      } else {
        equality.push(k);
      }
    }
  };
  walk(filter);
  return { equality: uniq(equality), range: uniq(range), complex: uniq(complex) };
}

export function sortFields(sort) {
  if (!isPlainObject(sort)) return [];
  return Object.entries(sort)
    .filter(([, d]) => d === 1 || d === -1)
    .map(([f, d]) => [f, d]);
}

/** ESR rule: Equality fields first, then Sort fields, then Range fields. */
export function recommendIndex({ filter, sort }) {
  const { equality, range, complex } = parseFilter(filter);
  const keys = [];
  const seen = new Set();
  const push = (f, d) => {
    if (!seen.has(f)) {
      seen.add(f);
      keys.push([f, d]);
    }
  };
  equality.forEach((f) => push(f, 1));
  sortFields(sort).forEach(([f, d]) => push(f, d));
  range.forEach((f) => push(f, 1));
  return keys.length ? { keys, complex } : null;
}

/** True if an existing index already starts with the recommended fields (in order). */
export function isCovered(indexes, keys) {
  const want = keys.map(([f]) => f);
  return indexes.some((ix) => {
    const have = Object.keys(ix.key);
    return want.every((f, i) => have[i] === f);
  });
}

/** Replace literal values with '?' so queries that differ only in values share a shape. */
export function normalizeFilter(f) {
  if (Array.isArray(f)) return f.map(normalizeFilter);
  if (isPlainObject(f)) {
    const out = {};
    for (const k of Object.keys(f).sort()) {
      const structural = k === '$and' || k === '$or' || k === '$nor';
      out[k] = k.startsWith('$') && !structural ? '?' : normalizeFilter(f[k]);
    }
    return out;
  }
  return '?';
}

export const shapeKey = (ns, filter, sort) => JSON.stringify([ns, normalizeFilter(filter || {}), sortFields(sort)]);

/** Turn a profile entry into a find-like description, or null if it isn't indexable. */
export function toQueryLike(e) {
  if (!e.ns || e.ns.includes('.system.')) return null;
  if (e.op === 'query' && e.command?.find) {
    return { ns: e.ns, filter: e.command.filter || {}, sort: e.command.sort, limit: e.command.limit, from: 'find' };
  }
  const pipe = e.op === 'command' && e.command?.aggregate && e.command.pipeline;
  if (Array.isArray(pipe) && pipe.length && isPlainObject(pipe[0]?.$match)) {
    const sort = isPlainObject(pipe[1]?.$sort) ? pipe[1].$sort : undefined;
    return { ns: e.ns, filter: pipe[0].$match, sort, limit: undefined, from: 'aggregate' };
  }
  return null;
}

/** Group system.profile entries (find, and aggregate with a leading $match) into query shapes. */
export function groupProfile(entries) {
  const groups = new Map();
  for (const e of entries) {
    const q = toQueryLike(e);
    if (!q) continue;
    const key = shapeKey(q.ns, q.filter, q.sort);
    let g = groups.get(key);
    if (!g) {
      g = {
        ns: q.ns, count: 0, totalMs: 0, maxMs: 0, examined: 0, returned: 0,
        plan: e.planSummary || '',
        example: { filter: q.filter, sort: q.sort, limit: q.limit, from: q.from },
      };
      groups.set(key, g);
    }
    g.count++;
    g.totalMs += e.millis || 0;
    g.maxMs = Math.max(g.maxMs, e.millis || 0);
    g.examined += e.docsExamined || 0;
    g.returned += e.nreturned || 0;
    if ((e.planSummary || '').startsWith('COLLSCAN')) g.plan = e.planSummary;
  }
  return [...groups.values()]
    .map((g) => ({
      ...g,
      avgMs: g.totalMs / g.count,
      avgExamined: g.examined / g.count,
      avgReturned: g.returned / g.count,
      scanRatio: g.examined / g.count / Math.max(g.returned / g.count, 1),
    }))
    .sort((a, b) => b.totalMs - a.totalMs);
}

/** Find $lookup stages (localField/foreignField form) in profiled aggregations. Skips pipelines that write. */
export function collectLookups(entries) {
  const found = new Map();
  for (const e of entries) {
    const pipe = e.op === 'command' && e.command?.aggregate && e.command.pipeline;
    if (!Array.isArray(pipe) || !e.ns || e.ns.includes('.system.')) continue;
    if (pipe.some((st) => st && ('$out' in st || '$merge' in st))) continue;
    const dbName = e.ns.slice(0, e.ns.indexOf('.'));
    for (const st of pipe) {
      const lk = st?.$lookup;
      if (!isPlainObject(lk) || typeof lk.from !== 'string' || typeof lk.foreignField !== 'string') continue;
      const foreignNs = `${dbName}.${lk.from}`;
      const key = `${foreignNs}|${lk.foreignField}`;
      let g = found.get(key);
      if (!g) found.set(key, (g = { sourceNs: e.ns, foreignNs, foreignField: lk.foreignField, count: 0, totalMs: 0, pipeline: pipe }));
      g.count++;
      g.totalMs += e.millis || 0;
    }
  }
  return [...found.values()].map((g) => ({ ...g, avgMs: g.totalMs / g.count }));
}

const collName = (ns) => ns.slice(ns.indexOf('.') + 1);
const keyText = (keys) => `{ ${keys.map(([f, d]) => `${f}: ${d}`).join(', ')} }`;

export function findQueryIssues(shapes, indexesByNs, { minExamined = 100, minRatio = 20 } = {}) {
  const found = new Map();
  for (const s of shapes) {
    // A scan that returns a big share of the collection can't be fixed by an index, so don't flag it.
    const scanning = (s.plan.startsWith('COLLSCAN') && s.scanRatio >= 5) || s.scanRatio >= minRatio;
    if (!scanning || s.avgExamined < minExamined) continue;
    const rec = recommendIndex(s.example);
    if (!rec) continue;
    if (isCovered(indexesByNs[s.ns] || [], rec.keys)) continue;

    const coll = collName(s.ns);
    const id = `missing_index:${s.ns}:${keyText(rec.keys)}`;
    const severity = s.scanRatio >= 1000 || s.avgMs >= 100 ? 'critical' : 'warning';
    const issue = {
      id, type: 'missing_index', severity, ns: s.ns,
      title: `Queries on ${coll} read ${fmtNum(s.avgExamined)} documents to return ${fmtNum(s.avgReturned)}`,
      detail: `${s.example.from === 'aggregate' ? 'From the leading $match of an aggregation. ' : ''}Seen ${s.count}x, averaging ${s.avgMs.toFixed(0)} ms (slowest ${s.maxMs} ms). ` +
        `Plan: ${s.plan || 'unknown'}. An index on ${keyText(rec.keys)} lets MongoDB jump straight to the matching documents.`,
      metrics: { count: s.count, avgMs: s.avgMs, avgExamined: s.avgExamined, avgReturned: s.avgReturned, scanRatio: s.scanRatio, plan: s.plan },
      command: `db.${coll}.createIndex(${keyText(rec.keys)})`,
      fix: { keys: rec.keys, example: s.example },
      totalMs: s.totalMs,
    };
    const prev = found.get(id);
    if (!prev || issue.totalMs > prev.totalMs) found.set(id, issue);
  }
  return [...found.values()];
}

export function findLookupIssues(lookups, indexesByNs, countsByNs) {
  const issues = [];
  for (const l of lookups) {
    if (l.foreignField === '_id') continue;
    const idx = indexesByNs[l.foreignNs];
    const rows = countsByNs[l.foreignNs] || 0;
    if (!idx || rows < 1000 || isCovered(idx, [[l.foreignField, 1]])) continue;
    const coll = collName(l.foreignNs);
    issues.push({
      id: `lookup_unindexed:${l.foreignNs}:${l.foreignField}`, type: 'lookup_unindexed',
      severity: rows >= 10000 || l.avgMs >= 200 ? 'critical' : 'warning', ns: l.foreignNs,
      title: `$lookup into ${coll} matches on unindexed ${l.foreignField}`,
      detail: `The join from ${collName(l.sourceNs)} ran ${l.count}x, averaging ${l.avgMs.toFixed(0)} ms. ` +
        `With no index on ${coll}.${l.foreignField}, MongoDB scans all ${fmtNum(rows)} documents of ${coll} for every document it joins.`,
      command: `db.${coll}.createIndex({ ${l.foreignField}: 1 })`,
      fix: { kind: 'lookup', keys: [[l.foreignField, 1]], foreignNs: l.foreignNs, sourceNs: l.sourceNs, pipeline: l.pipeline },
      metrics: { count: l.count, avgMs: l.avgMs },
      totalMs: l.totalMs,
    });
  }
  return issues;
}

/** Drop a lookup issue when a find-based index recommendation on the same field already covers it. */
export function dedupeLookupIssues(issues) {
  return issues.filter((l) => {
    if (l.type !== 'lookup_unindexed') return true;
    const twin = issues.find((m) => m.type === 'missing_index' && m.ns === l.ns && m.fix?.keys[0][0] === l.fix.keys[0][0]);
    if (twin) twin.detail += ` The same index also speeds up the $lookup from ${collName(l.fix.sourceNs)} (${l.metrics.count} runs).`;
    return !twin;
  });
}

// ---------------------------------------------------------------- indexes

export function findIndexIssues(ns, indexes, stats = []) {
  const issues = [];
  const coll = collName(ns);
  const fieldsOf = (ix) => Object.entries(ix.key).map(([f, d]) => `${f}:${d}`);
  for (const ix of indexes) {
    if (ix.name === '_id_') continue;
    const mine = fieldsOf(ix);
    const parent = indexes.find((o) => {
      if (o.name === ix.name) return false;
      const theirs = fieldsOf(o);
      return theirs.length > mine.length && mine.every((f, i) => theirs[i] === f);
    });
    if (parent && !ix.unique && !ix.expireAfterSeconds && !ix.partialFilterExpression) {
      issues.push({
        id: `redundant_index:${ns}:${ix.name}`, type: 'redundant_index', severity: 'warning', ns,
        title: `Index ${ix.name} on ${coll} is redundant`,
        detail: `${parent.name} already starts with the same fields, so ${ix.name} only adds write cost and storage.`,
        command: `db.${coll}.dropIndex("${ix.name}")`,
      });
      continue;
    }
    const st = stats.find((s) => s.name === ix.name);
    if (st && st.accesses?.ops === 0) {
      const since = st.accesses.since ? new Date(st.accesses.since).toISOString().slice(0, 10) : 'the last restart';
      issues.push({
        id: `unused_index:${ns}:${ix.name}`, type: 'unused_index', severity: 'warning', ns,
        title: `Index ${ix.name} on ${coll} has never been used`,
        detail: `No query has used it since ${since}. Every write still pays to maintain it. Confirm it isn't needed for rare jobs before dropping.`,
        command: `db.${coll}.dropIndex("${ix.name}")`,
      });
    }
  }
  return issues;
}

// ---------------------------------------------------------------- schema

export function typeOf(v) {
  if (v === null || v === undefined) return 'null';
  if (Array.isArray(v)) return 'array';
  if (v instanceof Date) return 'date';
  if (typeof v === 'object' && v._bsontype) {
    const t = String(v._bsontype).toLowerCase();
    return ['int32', 'double', 'long'].includes(t) ? 'number' : t;
  }
  return typeof v === 'object' ? 'object' : typeof v;
}

export function inferSchema(docs, sizeOf = () => 0, maxDepth = 2) {
  const fields = new Map();
  const visit = (obj, prefix, depth) => {
    for (const [k, v] of Object.entries(obj)) {
      const path = prefix ? `${prefix}.${k}` : k;
      const t = typeOf(v);
      let f = fields.get(path);
      if (!f) fields.set(path, (f = { types: {}, present: 0, maxArray: 0 }));
      f.types[t] = (f.types[t] || 0) + 1;
      f.present++;
      if (t === 'array') f.maxArray = Math.max(f.maxArray, v.length);
      if (t === 'object' && depth < maxDepth) visit(v, path, depth + 1);
    }
  };
  const sizes = [];
  for (const d of docs) {
    visit(d, '', 1);
    sizes.push(sizeOf(d));
  }
  sizes.sort((a, b) => a - b);
  return {
    sampled: docs.length,
    fields: [...fields.entries()].map(([path, f]) => ({ path, ...f })),
    maxBytes: sizes.length ? sizes[sizes.length - 1] : 0,
    over256k: sizes.filter((s) => s >= 256 * 1024).length,
  };
}

const CONVERT_TO = { number: 'double', string: 'string', bool: 'bool', date: 'date', objectid: 'objectId' };
const TYPE_ALIAS = { number: 'number', string: 'string', bool: 'bool', date: 'date', objectid: 'objectId' };

/** A (never auto-run) updateMany that converts stray values to the dominant type. */
export function coercionCommand(coll, path, dominant, minorities) {
  if (!CONVERT_TO[dominant] || !minorities.length || !minorities.every((t) => TYPE_ALIAS[t])) return null;
  const aliases = minorities.map((t) => `"${TYPE_ALIAS[t]}"`);
  const match = aliases.length === 1 ? `{ $type: ${aliases[0]} }` : `{ $type: [${aliases.join(', ')}] }`;
  return `db.${coll}.updateMany({ "${path}": ${match} }, [{ $set: { "${path}": { $convert: { input: "$${path}", to: "${CONVERT_TO[dominant]}", onError: "$${path}" } } } }])`;
}

export function findSchemaIssues(ns, schema) {
  const issues = [];
  const coll = collName(ns);
  const n = schema.sampled;

  for (const f of schema.fields) {
    const types = Object.entries(f.types).filter(([t]) => t !== 'null');
    if (types.length >= 2) {
      const total = types.reduce((a, [, c]) => a + c, 0);
      const top = Math.max(...types.map(([, c]) => c));
      const minority = 1 - top / total;
      types.sort((a, b) => b[1] - a[1]);
      const dist = types.map(([t, c]) => `${t} ${((c / total) * 100).toFixed(1)}%`).join(', ');
      const command = coercionCommand(coll, f.path, types[0][0], types.slice(1).map(([t]) => t));
      issues.push({
        id: `type_conflict:${ns}:${f.path}`, type: 'type_conflict',
        severity: minority >= 0.2 ? 'critical' : 'warning', ns,
        title: `${coll}.${f.path} stores mixed types`,
        detail: `In ${n} sampled documents: ${dist}. Mixed types break sorting, range queries and aggregations, because MongoDB orders values by type first.` +
          (command ? ' The command converts the stray values to the dominant type. Try it on a copy first.' : ''),
        command,
      });
    }
    if (f.maxArray >= 1000) {
      issues.push({
        id: `unbounded_array:${ns}:${f.path}`, type: 'unbounded_array',
        severity: f.maxArray >= 10000 ? 'critical' : 'warning', ns,
        title: `${coll}.${f.path} grows without a bound`,
        detail: `The longest array in the sample holds ${fmtNum(f.maxArray)} items. Large arrays inflate documents, slow updates and push toward the 16 MB document limit. Move the items to their own collection.`,
        command: null,
      });
    }
  }

  if (schema.maxBytes >= 256 * 1024) {
    issues.push({
      id: `large_documents:${ns}`, type: 'large_documents',
      severity: schema.maxBytes >= 1024 * 1024 ? 'critical' : 'warning', ns,
      title: `${coll} contains very large documents`,
      detail: `${schema.over256k} of ${n} sampled documents exceed 256 KB. The largest is ${fmtBytes(schema.maxBytes)}. The hard limit is 16 MB, and big documents crowd the cache.`,
      command: null,
    });
  }
  return issues;
}

// ---------------------------------------------------------------- score

const PENALTY = { critical: 15, warning: 6, info: 2 };
export function healthScore(issues) {
  return Math.max(0, 100 - issues.reduce((a, i) => a + (PENALTY[i.severity] || 0), 0));
}
const ORDER = { critical: 0, warning: 1, info: 2 };
export const sortIssues = (issues) =>
  [...issues].sort((a, b) => ORDER[a.severity] - ORDER[b.severity] || (b.totalMs || 0) - (a.totalMs || 0));
