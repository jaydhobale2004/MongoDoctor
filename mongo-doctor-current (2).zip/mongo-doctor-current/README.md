# Mongo Doctor

Finds slow queries, missing indexes, slow `$lookup` joins and schema problems in MongoDB, builds the fix, and shows the **measured** before/after.

## Run it

```bash
docker compose up -d     # MongoDB 7 on :27017
npm install
npm run selfcheck        # 1 min: end-to-end test against YOUR MongoDB. Run this first.
npm run seed             # builds an unhealthy "shop" db + frozen query history (~30 s)
npm start                # http://localhost:3000
```

In the page: **Run checkup**, then **Fix all** (or **Build index and measure** per finding). **Remove this index** undoes any fix.
No database? Click **Preview with sample data** (illustrative numbers, fixes disabled).

## What it checks

| Check | How |
|---|---|
| Missing index | Groups `system.profile` queries (`find`, and aggregations with a leading `$match`) by shape. Flags scans that return a small share of what they read, recommends an index with the ESR rule (Equality, Sort, Range) unless one already covers it |
| Slow `$lookup` | Finds joins whose `foreignField` has no index. Merged into the index finding when one index fixes both |
| Redundant / unused index | Prefix of another index / zero `$indexStats` accesses |
| Mixed types in a field | `$sample` of 300 docs per collection (falls back to the first 300 on servers without `$sample`). Gives a `$convert` command to fix stray values |
| Unbounded arrays, huge documents | Same sample; sizes via `BSON.calculateObjectSize` |

**Measuring:** find-style fixes use `explain("executionStats")` before and after (docs examined is exact, time is the median of 3 runs). Join fixes time the aggregation for its first 20 results (median of 3); pipelines containing `$out`/`$merge` are never run.

## Use in CI

```bash
node bin/ci.js --db shop --fail-on critical          # exit 0 healthy, 1 gate failed, 2 could not run
node bin/ci.js --db shop --min-score 80 --format markdown
```
Also downloadable from the UI as a Markdown report.

Optional **Explain** button (plain-English reasoning from an LLM). Set an API key as an environment variable before `npm start`:
- NVIDIA: `NVIDIA_API_KEY` (uses the app's configured NVIDIA endpoint and model)
- Anthropic: `ANTHROPIC_API_KEY` (optional `ANTHROPIC_MODEL`)

Easiest: copy `.env.example` to `.env` in the project folder, paste your key after `NVIDIA_API_KEY=`, save, and restart with `npm start`. The server loads `.env` automatically; non-empty environment variables take priority, while empty ones are treated as unset. `.env.example` is only a template and is not loaded directly. `.env` is git-ignored, so don't share or upload it.

NVIDIA is used if both keys are set.

## Layout

```
src/analyzer.js   pure logic, unit-tested (npm test)
src/doctor.js     MongoDB I/O: scan, measure, apply/revert
src/report.js     text + Markdown renderers
src/server.js     Express API, binds to 127.0.0.1
bin/ci.js         CI gate
public/index.html dashboard (no build step)
scripts/seed.js, scripts/selfcheck.js
```

## Known limits

- `createIndex` is real. On a large production collection it costs I/O; use a copy or staging.
- Index recommendations ignore sort-direction compatibility and value selectivity. Sanity-check them.
- `$or`, `$regex`, `$ne` filters and pipeline-style `$lookup` are skipped.
- `system.profile` is a 1 MB capped collection; on a busy system old entries roll off. The seed switches the profiler off after the workload so the history stays put for the demo.
- Needs profiler access for query findings (not available on Atlas shared tiers); index and schema checks still run.
- Local use only: the API has no auth.

## Demo script (2 min)

1. Run the checkup: low score, orders scan and the `profiles` join are critical.
2. **Fix all**: totals show documents examined dropping from ~200,000 to a handful, and the join going from hundreds of ms to a few.
3. Show the mixed-type `total` with its ready-made `$convert` command, the 25,000-item `events` arrays, and the redundant/unused index commands.
4. `node bin/ci.js --db shop` exits 1: the same checks as a pipeline gate.
